
RAW DATA NOTICE: figure 5c and 5f not included because dataset too large. 5b and 5e not included because contains genetic information.

remote: error: File plot_data/Figure5c.txt is 206.14 MB; this exceeds GitHub's file size limit of 100.00 MB

remote: error: File plot_data/Figure5f.txt is 206.29 MB; this exceeds GitHub's file size limit of 100.00 MB

